// Demo store using in-memory state with event emitter pattern for real-time updates

export interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  category: "starters" | "mains" | "desserts" | "drinks"
  image?: string
}

export interface OrderItem {
  menuItem: MenuItem
  quantity: number
}

export interface QueueEntry {
  id: string
  customerName: string
  partySize: number
  phone: string
  status: "waiting" | "called" | "seated" | "completed" | "cancelled"
  joinedAt: Date
  estimatedWait: number
  notes?: string
  orders: OrderItem[]
}

export interface Appointment {
  id: string
  customerName: string
  phone: string
  date: string
  time: string
  partySize: number
  status: "confirmed" | "cancelled" | "completed"
  notes?: string
}

export interface Restaurant {
  id: string
  name: string
  description: string
  averageServiceTime: number // minutes per party
}

// Demo data
const demoRestaurant: Restaurant = {
  id: "rest-001",
  name: "The Golden Fork",
  description: "Fine dining experience with modern cuisine",
  averageServiceTime: 45,
}

const demoMenu: MenuItem[] = [
  {
    id: "m1",
    name: "Crispy Calamari",
    description: "Lightly battered squid with aioli dip",
    price: 12.99,
    category: "starters",
  },
  {
    id: "m2",
    name: "Bruschetta",
    description: "Toasted bread with tomato, basil, and olive oil",
    price: 8.99,
    category: "starters",
  },
  {
    id: "m3",
    name: "Soup of the Day",
    description: "Chef's special soup served with bread",
    price: 7.99,
    category: "starters",
  },
  {
    id: "m4",
    name: "Grilled Salmon",
    description: "Atlantic salmon with lemon butter sauce and vegetables",
    price: 24.99,
    category: "mains",
  },
  {
    id: "m5",
    name: "Ribeye Steak",
    description: "10oz prime ribeye with mashed potatoes",
    price: 32.99,
    category: "mains",
  },
  {
    id: "m6",
    name: "Mushroom Risotto",
    description: "Creamy arborio rice with wild mushrooms",
    price: 18.99,
    category: "mains",
  },
  {
    id: "m7",
    name: "Chicken Parmesan",
    description: "Breaded chicken with marinara and mozzarella",
    price: 21.99,
    category: "mains",
  },
  {
    id: "m8",
    name: "Tiramisu",
    description: "Classic Italian coffee-flavored dessert",
    price: 9.99,
    category: "desserts",
  },
  {
    id: "m9",
    name: "Chocolate Lava Cake",
    description: "Warm chocolate cake with molten center",
    price: 10.99,
    category: "desserts",
  },
  {
    id: "m10",
    name: "Fresh Lemonade",
    description: "House-made lemonade with mint",
    price: 4.99,
    category: "drinks",
  },
  {
    id: "m11",
    name: "Iced Tea",
    description: "Refreshing brewed iced tea",
    price: 3.99,
    category: "drinks",
  },
  {
    id: "m12",
    name: "Espresso",
    description: "Double shot Italian espresso",
    price: 3.49,
    category: "drinks",
  },
]

const demoQueue: QueueEntry[] = [
  {
    id: "q1",
    customerName: "John Smith",
    partySize: 4,
    phone: "+1 555-0101",
    status: "waiting",
    joinedAt: new Date(Date.now() - 25 * 60000),
    estimatedWait: 15,
    orders: [],
  },
  {
    id: "q2",
    customerName: "Sarah Johnson",
    partySize: 2,
    phone: "+1 555-0102",
    status: "waiting",
    joinedAt: new Date(Date.now() - 15 * 60000),
    estimatedWait: 25,
    orders: [],
  },
  {
    id: "q3",
    customerName: "Mike Chen",
    partySize: 6,
    phone: "+1 555-0103",
    status: "waiting",
    joinedAt: new Date(Date.now() - 5 * 60000),
    estimatedWait: 35,
    orders: [],
  },
]

const demoAppointments: Appointment[] = [
  {
    id: "a1",
    customerName: "Emily Davis",
    phone: "+1 555-0201",
    date: new Date().toISOString().split("T")[0],
    time: "18:00",
    partySize: 4,
    status: "confirmed",
  },
  {
    id: "a2",
    customerName: "Robert Wilson",
    phone: "+1 555-0202",
    date: new Date().toISOString().split("T")[0],
    time: "19:30",
    partySize: 2,
    status: "confirmed",
  },
]

// Event-based store for real-time updates
type Listener = () => void
const listeners: Set<Listener> = new Set()

let queue: QueueEntry[] = [...demoQueue]
let appointments: Appointment[] = [...demoAppointments]

// Cached snapshots for useSyncExternalStore (must return stable references)
let queueSnapshot: QueueEntry[] = queue
let appointmentsSnapshot: Appointment[] = appointments
let entrySnapshots: Map<string, QueueEntry | undefined> = new Map()

export const queueStore = {
  // Subscribe to changes
  subscribe(listener: Listener) {
    listeners.add(listener)
    return () => listeners.delete(listener)
  },

  // Notify all listeners and update snapshots
  notify() {
    // Create new snapshot references when data changes
    queueSnapshot = [...queue]
    appointmentsSnapshot = [...appointments]
    // Clear entry cache so it gets refreshed
    entrySnapshots = new Map()
    listeners.forEach((l) => l())
  },

  // Restaurant
  getRestaurant() {
    return demoRestaurant
  },

  // Menu
  getMenu() {
    return demoMenu
  },

  getMenuByCategory(category: MenuItem["category"]) {
    return demoMenu.filter((item) => item.category === category)
  },

  // Queue operations
  getQueue() {
    return queueSnapshot
  },

  getQueueEntry(id: string) {
    if (!entrySnapshots.has(id)) {
      entrySnapshots.set(id, queue.find((entry) => entry.id === id))
    }
    return entrySnapshots.get(id)
  },

  getWaitingCount() {
    return queue.filter((e) => e.status === "waiting").length
  },

  getPosition(id: string) {
    const waiting = queue.filter((e) => e.status === "waiting")
    return waiting.findIndex((e) => e.id === id) + 1
  },

  addToQueue(entry: Omit<QueueEntry, "id" | "joinedAt" | "estimatedWait" | "status">) {
    const waitingCount = this.getWaitingCount()
    const newEntry: QueueEntry = {
      ...entry,
      id: `q${Date.now()}`,
      status: "waiting",
      joinedAt: new Date(),
      estimatedWait: (waitingCount + 1) * demoRestaurant.averageServiceTime / 3,
    }
    queue.push(newEntry)
    this.notify()
    return newEntry
  },

  updateQueueEntry(id: string, updates: Partial<QueueEntry>) {
    const index = queue.findIndex((e) => e.id === id)
    if (index !== -1) {
      queue[index] = { ...queue[index], ...updates }
      this.notify()
      return queue[index]
    }
    return null
  },

  callNext() {
    const next = queue.find((e) => e.status === "waiting")
    if (next) {
      return this.updateQueueEntry(next.id, { status: "called" })
    }
    return null
  },

  seatCustomer(id: string) {
    return this.updateQueueEntry(id, { status: "seated" })
  },

  completeCustomer(id: string) {
    return this.updateQueueEntry(id, { status: "completed" })
  },

  cancelEntry(id: string) {
    return this.updateQueueEntry(id, { status: "cancelled" })
  },

  removeEntry(id: string) {
    queue = queue.filter((e) => e.id !== id)
    this.notify()
  },

  // Order operations
  addOrder(queueId: string, menuItem: MenuItem, quantity: number = 1) {
    const entry = queue.find((e) => e.id === queueId)
    if (entry) {
      const existingOrder = entry.orders.find((o) => o.menuItem.id === menuItem.id)
      if (existingOrder) {
        existingOrder.quantity += quantity
      } else {
        entry.orders.push({ menuItem, quantity })
      }
      this.notify()
      return entry
    }
    return null
  },

  removeOrder(queueId: string, menuItemId: string) {
    const entry = queue.find((e) => e.id === queueId)
    if (entry) {
      entry.orders = entry.orders.filter((o) => o.menuItem.id !== menuItemId)
      this.notify()
      return entry
    }
    return null
  },

  getOrderTotal(queueId: string) {
    const entry = queue.find((e) => e.id === queueId)
    if (entry) {
      return entry.orders.reduce((sum, o) => sum + o.menuItem.price * o.quantity, 0)
    }
    return 0
  },

  // Appointment operations
  getAppointments() {
    return appointmentsSnapshot
  },

  getAppointmentsByDate(date: string) {
    return appointments.filter((a) => a.date === date)
  },

  addAppointment(appointment: Omit<Appointment, "id" | "status">) {
    const newAppointment: Appointment = {
      ...appointment,
      id: `a${Date.now()}`,
      status: "confirmed",
    }
    appointments.push(newAppointment)
    this.notify()
    return newAppointment
  },

  cancelAppointment(id: string) {
    const appointment = appointments.find((a) => a.id === id)
    if (appointment) {
      appointment.status = "cancelled"
      this.notify()
      return appointment
    }
    return null
  },

  // Get available time slots for a date
  getAvailableSlots(date: string) {
    const bookedTimes = appointments
      .filter((a) => a.date === date && a.status === "confirmed")
      .map((a) => a.time)
    
    const allSlots = [
      "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
      "14:00", "14:30", "17:00", "17:30", "18:00", "18:30",
      "19:00", "19:30", "20:00", "20:30", "21:00"
    ]
    
    return allSlots.filter((slot) => !bookedTimes.includes(slot))
  },

  // Reset to demo data
  reset() {
    queue = [...demoQueue]
    appointments = [...demoAppointments]
    this.notify()
  },
}
