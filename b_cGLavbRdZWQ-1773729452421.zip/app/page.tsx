import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  Users, 
  QrCode, 
  Clock, 
  LayoutDashboard, 
  CalendarCheck, 
  UtensilsCrossed,
  ArrowRight,
  Zap,
  Shield,
  BarChart3,
  ShoppingBag
} from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg">QueueFlow</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="#demo" className="text-muted-foreground hover:text-foreground transition-colors">
              Demo
            </Link>
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/dashboard">Sign In</Link>
            </Button>
            <Button asChild>
              <Link href="/join/demo">Try Demo</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm mb-6">
              <Zap className="w-4 h-4" />
              Smart Queue Management
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 text-balance">
              Eliminate Wait Times with{" "}
              <span className="text-primary">QR-Based</span> Queue Management
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
              Let customers join your queue by scanning a QR code. Real-time updates, 
              menu ordering, and appointment booking - all in one platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="gap-2">
                <Link href="/join/demo">
                  Join Demo Queue
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/dashboard">Open Dashboard</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Everything You Need</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A complete solution for managing queues, appointments, and orders
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <FeatureCard 
              icon={QrCode}
              title="QR Code Join"
              description="Customers scan to join queue instantly - no app download required"
            />
            <FeatureCard 
              icon={Clock}
              title="Live Wait Times"
              description="Real-time position updates and estimated wait time notifications"
            />
            <FeatureCard 
              icon={LayoutDashboard}
              title="Owner Dashboard"
              description="Manage your queue, call customers, and view analytics"
            />
            <FeatureCard 
              icon={UtensilsCrossed}
              title="Menu & Ordering"
              description="Let customers browse menu and pre-order while waiting"
            />
            <FeatureCard 
              icon={CalendarCheck}
              title="Appointment Booking"
              description="Schedule reservations with available time slots"
            />
            <FeatureCard 
              icon={Users}
              title="Party Management"
              description="Handle different party sizes with smart table allocation"
            />
          </div>
        </div>
      </section>

      {/* Demo Links */}
      <section id="demo" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Try the Demo</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Experience all features with our interactive demo
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 max-w-6xl mx-auto">
            <DemoCard 
              href="/dashboard"
              icon={LayoutDashboard}
              title="Owner Dashboard"
              description="Manage queue and view orders"
            />
            <DemoCard 
              href="/join/demo"
              icon={QrCode}
              title="Join Queue"
              description="Scan QR and join queue"
            />
            <DemoCard 
              href="/order/demo"
              icon={ShoppingBag}
              title="Table Order"
              description="Scan QR to order from table"
            />
            <DemoCard 
              href="/display/demo"
              icon={Users}
              title="Queue Display"
              description="Live queue screen for TV"
            />
            <DemoCard 
              href="/book/demo"
              icon={CalendarCheck}
              title="Book Table"
              description="Reserve a table in advance"
            />
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Fast Setup</h3>
                <p className="text-muted-foreground text-sm">
                  Get started in minutes. Just create your queue and share the QR code.
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">No App Required</h3>
                <p className="text-muted-foreground text-sm">
                  Customers just scan and join. Works on any smartphone browser.
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Real-time Analytics</h3>
                <p className="text-muted-foreground text-sm">
                  Track wait times, peak hours, and customer flow.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-medium">QueueFlow</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Demo prototype - Built for queue management
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ElementType
  title: string
  description: string 
}) {
  return (
    <Card className="bg-card border-border hover:border-primary/50 transition-colors">
      <CardHeader>
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-muted-foreground">
          {description}
        </CardDescription>
      </CardContent>
    </Card>
  )
}

function DemoCard({ 
  href, 
  icon: Icon, 
  title, 
  description 
}: { 
  href: string
  icon: React.ElementType
  title: string
  description: string 
}) {
  return (
    <Link href={href}>
      <Card className="bg-card border-border hover:border-primary hover:bg-card/80 transition-all group cursor-pointer h-full">
        <CardContent className="pt-6">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <h3 className="font-semibold mb-1">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
          <div className="mt-4 flex items-center gap-1 text-primary text-sm font-medium">
            Open
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
