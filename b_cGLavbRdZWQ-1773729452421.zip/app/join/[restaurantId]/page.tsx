"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useQueue, useMenu, useRestaurant, useOrders } from "@/hooks/use-queue"
import { queueStore, MenuItem } from "@/lib/queue-store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Users, 
  Clock, 
  Zap,
  ArrowLeft,
  CheckCircle2,
  UtensilsCrossed,
  Plus,
  Minus,
  ShoppingBag,
  User,
  Phone,
  MessageSquare,
  Loader2
} from "lucide-react"

type Step = "join" | "waiting" | "menu"

export default function JoinQueuePage() {
  const { addToQueue, getPosition, getEntry, waitingCount } = useQueue()
  const { menu, getByCategory } = useMenu()
  const restaurant = useRestaurant()
  
  const [step, setStep] = useState<Step>("join")
  const [queueId, setQueueId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    partySize: 2,
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Get current queue entry and position
  const entry = queueId ? getEntry(queueId) : null
  const position = queueId ? getPosition(queueId) : 0

  // Auto-refresh to track position changes
  useEffect(() => {
    if (queueId && entry?.status === "called") {
      // Entry has been called
    }
  }, [queueId, entry])

  const handleJoin = async () => {
    if (!formData.name || !formData.phone) return
    
    setIsSubmitting(true)
    // Simulate a brief delay for UX
    await new Promise((resolve) => setTimeout(resolve, 500))
    
    const newEntry = addToQueue({
      customerName: formData.name,
      phone: formData.phone,
      partySize: formData.partySize,
      notes: formData.notes,
      orders: [],
    })
    
    setQueueId(newEntry.id)
    setStep("waiting")
    setIsSubmitting(false)
  }

  if (step === "join") {
    return (
      <div className="min-h-screen bg-background">
        <JoinHeader restaurant={restaurant} />
        
        <main className="container mx-auto px-4 py-6 max-w-md">
          {/* Current Wait Info */}
          <Card className="bg-card border-border mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{waitingCount}</p>
                    <p className="text-xs text-muted-foreground">Currently waiting</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold">{waitingCount * 15}min</p>
                  <p className="text-xs text-muted-foreground">Est. wait time</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Join Form */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Join the Queue</CardTitle>
              <CardDescription>Enter your details to get in line</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  Your Name
                </label>
                <Input
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  Phone Number
                </label>
                <Input
                  type="tel"
                  placeholder="+1 555-0123"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  Party Size
                </label>
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFormData({ ...formData, partySize: Math.max(1, formData.partySize - 1) })}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="text-2xl font-bold w-12 text-center">{formData.partySize}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFormData({ ...formData, partySize: Math.min(12, formData.partySize + 1) })}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-muted-foreground" />
                  Special Requests (optional)
                </label>
                <Input
                  placeholder="High chair needed, window seat..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <Button 
                className="w-full" 
                size="lg"
                onClick={handleJoin}
                disabled={!formData.name || !formData.phone || isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Joining...
                  </>
                ) : (
                  <>
                    Join Queue
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  if (step === "waiting" && entry) {
    return (
      <div className="min-h-screen bg-background">
        <JoinHeader restaurant={restaurant} />
        
        <main className="container mx-auto px-4 py-6 max-w-md">
          {/* Status Card */}
          <Card className={`border-2 mb-6 ${entry.status === "called" ? "border-warning bg-warning/5 animate-pulse" : "border-border"}`}>
            <CardContent className="p-6 text-center">
              {entry.status === "called" ? (
                <>
                  <div className="w-16 h-16 rounded-full bg-warning/20 flex items-center justify-center mx-auto mb-4 animate-bounce">
                    <CheckCircle2 className="w-8 h-8 text-warning" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Your Table is Ready!</h2>
                  <p className="text-muted-foreground">Please head to the host stand</p>
                </>
              ) : (
                <>
                  <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-4xl font-bold text-primary">#{position}</span>
                  </div>
                  <h2 className="text-xl font-semibold mb-1">You are #{position} in line</h2>
                  <p className="text-muted-foreground">
                    Estimated wait: ~{entry.estimatedWait} minutes
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          {/* Customer Details */}
          <Card className="bg-card border-border mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{entry.customerName}</p>
                  <p className="text-sm text-muted-foreground">Party of {entry.partySize}</p>
                </div>
                <Badge variant="secondary">
                  <Clock className="w-3 h-3 mr-1" />
                  {Math.floor((Date.now() - new Date(entry.joinedAt).getTime()) / 60000)}m wait
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Browse Menu Button */}
          <Button 
            variant="outline" 
            className="w-full mb-4"
            size="lg"
            onClick={() => setStep("menu")}
          >
            <UtensilsCrossed className="w-4 h-4 mr-2" />
            Browse Menu & Pre-Order
          </Button>

          {/* Pre-orders */}
          {entry.orders.length > 0 && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" />
                  Your Pre-Order
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {entry.orders.map((order) => (
                    <div key={order.menuItem.id} className="flex items-center justify-between text-sm">
                      <span>{order.quantity}x {order.menuItem.name}</span>
                      <span className="text-muted-foreground">${(order.menuItem.price * order.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="border-t border-border pt-2 flex items-center justify-between font-medium">
                    <span>Total</span>
                    <span className="text-primary">${queueStore.getOrderTotal(entry.id).toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    )
  }

  if (step === "menu" && queueId) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 h-14 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setStep("waiting")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <p className="font-semibold">Menu</p>
              <p className="text-xs text-muted-foreground">{restaurant.name}</p>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-6 max-w-md pb-24">
          <MenuBrowser queueId={queueId} />
        </main>

        {/* Order Summary Footer */}
        <OrderSummaryFooter queueId={queueId} onBack={() => setStep("waiting")} />
      </div>
    )
  }

  return null
}

function JoinHeader({ restaurant }: { restaurant: { name: string; description: string } }) {
  return (
    <header className="border-b border-border bg-card/50">
      <div className="container mx-auto px-4 py-6">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{restaurant.name}</h1>
            <p className="text-sm text-muted-foreground">{restaurant.description}</p>
          </div>
        </div>
      </div>
    </header>
  )
}

function MenuBrowser({ queueId }: { queueId: string }) {
  const { menu } = useMenu()
  const { addOrder } = useOrders(queueId)
  
  const categories = [
    { id: "starters", label: "Starters" },
    { id: "mains", label: "Mains" },
    { id: "desserts", label: "Desserts" },
    { id: "drinks", label: "Drinks" },
  ] as const

  return (
    <Tabs defaultValue="starters" className="space-y-4">
      <TabsList className="w-full bg-card border border-border grid grid-cols-4">
        {categories.map((cat) => (
          <TabsTrigger key={cat.id} value={cat.id} className="text-xs">
            {cat.label}
          </TabsTrigger>
        ))}
      </TabsList>

      {categories.map((cat) => (
        <TabsContent key={cat.id} value={cat.id} className="space-y-3 mt-4">
          {menu
            .filter((item) => item.category === cat.id)
            .map((item) => (
              <MenuItemCard key={item.id} item={item} onAdd={() => addOrder(item)} />
            ))}
        </TabsContent>
      ))}
    </Tabs>
  )
}

function MenuItemCard({ item, onAdd }: { item: MenuItem; onAdd: () => void }) {
  const [added, setAdded] = useState(false)

  const handleAdd = () => {
    onAdd()
    setAdded(true)
    setTimeout(() => setAdded(false), 1500)
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h3 className="font-medium">{item.name}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            <p className="text-primary font-semibold mt-2">${item.price.toFixed(2)}</p>
          </div>
          <Button 
            size="sm" 
            variant={added ? "default" : "outline"}
            onClick={handleAdd}
            className="shrink-0"
          >
            {added ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <Plus className="w-4 h-4" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function OrderSummaryFooter({ queueId, onBack }: { queueId: string; onBack: () => void }) {
  const { orders, total } = useOrders(queueId)

  if (orders.length === 0) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4">
      <div className="container mx-auto max-w-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{orders.length} items</p>
            <p className="text-lg font-bold">${total.toFixed(2)}</p>
          </div>
          <Button onClick={onBack} className="gap-2">
            <ShoppingBag className="w-4 h-4" />
            View Order
          </Button>
        </div>
      </div>
    </div>
  )
}
