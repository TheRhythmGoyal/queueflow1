"use client"

import { useState, useMemo } from "react"
import { useParams } from "next/navigation"
import { queueStore, MenuItem } from "@/lib/queue-store"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  UtensilsCrossed,
  Plus,
  Minus,
  ShoppingCart,
  CheckCircle2,
  X,
  Search,
  Clock,
  ChefHat,
  Sparkles,
  Send,
  Phone,
  User,
  ArrowRight
} from "lucide-react"

interface CartItem {
  menuItem: MenuItem
  quantity: number
  notes?: string
}

type OrderStatus = "browsing" | "cart" | "details" | "confirmed"

export default function CustomerOrderPage() {
  const params = useParams()
  const tableId = params.restaurantId as string
  const restaurant = queueStore.getRestaurant()
  const menu = queueStore.getMenu()

  const [status, setStatus] = useState<OrderStatus>("browsing")
  const [cart, setCart] = useState<CartItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [customerDetails, setCustomerDetails] = useState({ name: "", phone: "" })
  const [orderNumber, setOrderNumber] = useState<string | null>(null)

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0)
  }, [cart])

  const cartItemCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0)
  }, [cart])

  const addToCart = (menuItem: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(item => item.menuItem.id === menuItem.id)
      if (existing) {
        return prev.map(item =>
          item.menuItem.id === menuItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { menuItem, quantity: 1 }]
    })
  }

  const updateQuantity = (menuItemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.menuItem.id === menuItemId) {
            const newQuantity = item.quantity + delta
            return newQuantity > 0 ? { ...item, quantity: newQuantity } : null
          }
          return item
        })
        .filter((item): item is CartItem => item !== null)
    })
  }

  const removeFromCart = (menuItemId: string) => {
    setCart(prev => prev.filter(item => item.menuItem.id !== menuItemId))
  }

  const handleSubmitOrder = () => {
    // Generate order number
    const ordNum = `ORD-${Date.now().toString().slice(-6)}`
    setOrderNumber(ordNum)
    setStatus("confirmed")
  }

  const filteredMenu = menu.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Confirmed Order Screen
  if (status === "confirmed") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-card border-border text-center">
          <CardContent className="p-8">
            <div className="w-20 h-20 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-success" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Order Placed!</h1>
            <p className="text-muted-foreground mb-6">
              Your order has been sent to the kitchen
            </p>
            
            <div className="bg-secondary rounded-lg p-4 mb-6">
              <p className="text-sm text-muted-foreground mb-1">Order Number</p>
              <p className="text-3xl font-mono font-bold text-primary">{orderNumber}</p>
            </div>

            <div className="space-y-2 text-left mb-6 bg-secondary/50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span>Estimated: 15-20 minutes</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <UtensilsCrossed className="w-4 h-4 text-muted-foreground" />
                <span>Table: {tableId}</span>
              </div>
            </div>

            <div className="border-t border-border pt-4">
              <p className="text-sm text-muted-foreground mb-3">Order Summary</p>
              <div className="space-y-2">
                {cart.map(item => (
                  <div key={item.menuItem.id} className="flex justify-between text-sm">
                    <span>{item.quantity}x {item.menuItem.name}</span>
                    <span>${(item.menuItem.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="flex justify-between font-bold pt-2 border-t border-border">
                  <span>Total</span>
                  <span className="text-primary">${cartTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <Button 
              className="w-full mt-6" 
              variant="outline"
              onClick={() => {
                setCart([])
                setStatus("browsing")
                setOrderNumber(null)
              }}
            >
              Place Another Order
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Customer Details Screen
  if (status === "details") {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 h-14 flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => setStatus("cart")}>
              Back
            </Button>
            <div className="flex-1">
              <p className="font-semibold">Checkout</p>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-6 max-w-md">
          <Card className="bg-card border-border mb-6">
            <CardContent className="p-6 space-y-4">
              <h2 className="font-semibold text-lg">Your Details</h2>
              
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  Name
                </label>
                <Input
                  placeholder="Enter your name"
                  value={customerDetails.name}
                  onChange={(e) => setCustomerDetails(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  Phone (optional)
                </label>
                <Input
                  type="tel"
                  placeholder="For order updates"
                  value={customerDetails.phone}
                  onChange={(e) => setCustomerDetails(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border mb-6">
            <CardContent className="p-4">
              <h3 className="font-medium mb-3">Order Summary</h3>
              <div className="space-y-2">
                {cart.map(item => (
                  <div key={item.menuItem.id} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.quantity}x {item.menuItem.name}</span>
                    <span>${(item.menuItem.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="flex justify-between font-bold pt-3 border-t border-border">
                  <span>Total</span>
                  <span className="text-primary">${cartTotal.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button 
            className="w-full" 
            size="lg"
            onClick={handleSubmitOrder}
            disabled={!customerDetails.name}
          >
            <Send className="w-4 h-4 mr-2" />
            Place Order - ${cartTotal.toFixed(2)}
          </Button>
        </main>
      </div>
    )
  }

  // Cart Screen
  if (status === "cart") {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 h-14 flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => setStatus("browsing")}>
              Back to Menu
            </Button>
            <div className="flex-1">
              <p className="font-semibold">Your Cart</p>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-6 max-w-md pb-32">
          {cart.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Your cart is empty</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setStatus("browsing")}
              >
                Browse Menu
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map(item => (
                <Card key={item.menuItem.id} className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-1">
                        <h3 className="font-medium">{item.menuItem.name}</h3>
                        <p className="text-sm text-muted-foreground">{item.menuItem.description}</p>
                        <p className="text-primary font-semibold mt-2">
                          ${(item.menuItem.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6"
                          onClick={() => removeFromCart(item.menuItem.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.menuItem.id, -1)}
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-8 text-center font-medium">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.menuItem.id, 1)}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>

        {cart.length > 0 && (
          <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4">
            <div className="container mx-auto max-w-md">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-muted-foreground">{cartItemCount} items</p>
                  <p className="text-xl font-bold">${cartTotal.toFixed(2)}</p>
                </div>
                <Button size="lg" onClick={() => setStatus("details")}>
                  Checkout
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  // Browsing Menu Screen (default)
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <UtensilsCrossed className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <h1 className="font-bold">{restaurant.name}</h1>
              <p className="text-xs text-muted-foreground">Table {tableId}</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="relative"
              onClick={() => setStatus("cart")}
            >
              <ShoppingCart className="w-4 h-4" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 w-5 h-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search menu..."
              className="pl-9 bg-secondary border-border"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      {/* Featured Section */}
      <section className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-primary" />
          <h2 className="font-semibold">Chef&apos;s Specials</h2>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
          {menu.slice(0, 3).map(item => (
            <Card key={item.id} className="bg-card border-border min-w-[200px] flex-shrink-0">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-2">
                  <ChefHat className="w-4 h-4 text-primary" />
                  <Badge variant="secondary" className="text-xs">Special</Badge>
                </div>
                <h3 className="font-medium text-sm">{item.name}</h3>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-primary font-semibold">${item.price.toFixed(2)}</span>
                  <Button size="sm" variant="outline" onClick={() => addToCart(item)}>
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Menu Tabs */}
      <main className="container mx-auto px-4 pb-24">
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList className="w-full bg-card border border-border grid grid-cols-5">
            <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
            <TabsTrigger value="starters" className="text-xs">Starters</TabsTrigger>
            <TabsTrigger value="mains" className="text-xs">Mains</TabsTrigger>
            <TabsTrigger value="desserts" className="text-xs">Desserts</TabsTrigger>
            <TabsTrigger value="drinks" className="text-xs">Drinks</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-3 mt-4">
            {filteredMenu.map(item => (
              <MenuCard key={item.id} item={item} onAdd={addToCart} cart={cart} />
            ))}
          </TabsContent>

          {(["starters", "mains", "desserts", "drinks"] as const).map(category => (
            <TabsContent key={category} value={category} className="space-y-3 mt-4">
              {filteredMenu
                .filter(item => item.category === category)
                .map(item => (
                  <MenuCard key={item.id} item={item} onAdd={addToCart} cart={cart} />
                ))}
            </TabsContent>
          ))}
        </Tabs>
      </main>

      {/* Floating Cart Button */}
      {cartItemCount > 0 && (
        <div className="fixed bottom-4 left-4 right-4 z-50">
          <Button 
            className="w-full max-w-md mx-auto flex items-center justify-between h-14 px-6"
            onClick={() => setStatus("cart")}
          >
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                <span className="text-sm font-bold">{cartItemCount}</span>
              </div>
              <span>View Cart</span>
            </div>
            <span className="font-bold">${cartTotal.toFixed(2)}</span>
          </Button>
        </div>
      )}
    </div>
  )
}

function MenuCard({ 
  item, 
  onAdd, 
  cart 
}: { 
  item: MenuItem
  onAdd: (item: MenuItem) => void
  cart: CartItem[]
}) {
  const cartItem = cart.find(c => c.menuItem.id === item.id)
  const [justAdded, setJustAdded] = useState(false)

  const handleAdd = () => {
    onAdd(item)
    setJustAdded(true)
    setTimeout(() => setJustAdded(false), 1000)
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-medium">{item.name}</h3>
              {cartItem && (
                <Badge variant="secondary" className="text-xs">
                  x{cartItem.quantity}
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
              {item.description}
            </p>
            <p className="text-primary font-semibold mt-2">${item.price.toFixed(2)}</p>
          </div>
          <Button
            size="sm"
            variant={justAdded ? "default" : "outline"}
            onClick={handleAdd}
            className="shrink-0"
          >
            {justAdded ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <Plus className="w-4 h-4" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
