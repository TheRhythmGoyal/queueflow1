"use client"

import { useState } from "react"
import Link from "next/link"
import { useQueue, useAppointments, useRestaurant } from "@/hooks/use-queue"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Bell,
  ChevronRight,
  QrCode,
  CalendarDays,
  UtensilsCrossed,
  Zap,
  Home,
  Monitor,
  PhoneCall,
  UserCheck,
  Trash2
} from "lucide-react"
import { QueueEntry } from "@/lib/queue-store"
import { QRCodeDisplay } from "@/components/qr-code-display"

export default function DashboardPage() {
  const { queue, waitingCount, calledCount, callNext, seatCustomer, completeCustomer, cancelEntry, removeEntry } = useQueue()
  const { appointments } = useAppointments()
  const restaurant = useRestaurant()
  const [showQR, setShowQR] = useState(false)
  const [qrType, setQRType] = useState<"queue" | "order">("queue")

  const todaysAppointments = appointments.filter(
    (a) => a.date === new Date().toISOString().split("T")[0] && a.status === "confirmed"
  )

  const waitingQueue = queue.filter((e) => e.status === "waiting")
  const calledQueue = queue.filter((e) => e.status === "called")
  const seatedQueue = queue.filter((e) => e.status === "seated")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-semibold text-lg">QueueFlow</span>
            </Link>
            <Badge variant="secondary" className="hidden sm:inline-flex">
              {restaurant.name}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/display/demo" className="gap-2">
                <Monitor className="w-4 h-4" />
                <span className="hidden sm:inline">Display</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" onClick={() => { setQRType("order"); setShowQR(true) }} className="gap-2">
              <UtensilsCrossed className="w-4 h-4" />
              <span className="hidden sm:inline">Table QR</span>
            </Button>
            <Button size="sm" onClick={() => { setQRType("queue"); setShowQR(true) }} className="gap-2">
              <QrCode className="w-4 h-4" />
              <span className="hidden sm:inline">Queue QR</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <StatCard 
            icon={Users}
            label="Waiting"
            value={waitingCount}
            color="text-primary"
          />
          <StatCard 
            icon={Bell}
            label="Called"
            value={calledCount}
            color="text-warning"
          />
          <StatCard 
            icon={CheckCircle2}
            label="Seated"
            value={seatedQueue.length}
            color="text-success"
          />
          <StatCard 
            icon={CalendarDays}
            label="Today's Bookings"
            value={todaysAppointments.length}
            color="text-muted-foreground"
          />
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-3 mb-6">
          <Button onClick={() => callNext()} disabled={waitingCount === 0} className="gap-2">
            <PhoneCall className="w-4 h-4" />
            Call Next Customer
          </Button>
          <Button variant="outline" asChild className="gap-2">
            <Link href="/">
              <Home className="w-4 h-4" />
              Home
            </Link>
          </Button>
        </div>

        {/* Queue Management Tabs */}
        <Tabs defaultValue="queue" className="space-y-4">
          <TabsList className="bg-card border border-border">
            <TabsTrigger value="queue" className="gap-2">
              <Users className="w-4 h-4" />
              Queue ({waitingQueue.length + calledQueue.length})
            </TabsTrigger>
            <TabsTrigger value="seated" className="gap-2">
              <UtensilsCrossed className="w-4 h-4" />
              Seated ({seatedQueue.length})
            </TabsTrigger>
            <TabsTrigger value="appointments" className="gap-2">
              <CalendarDays className="w-4 h-4" />
              Appointments ({todaysAppointments.length})
            </TabsTrigger>
          </TabsList>

          {/* Queue Tab */}
          <TabsContent value="queue" className="space-y-4">
            {/* Called customers first */}
            {calledQueue.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Called - Waiting to be Seated
                </h3>
                {calledQueue.map((entry) => (
                  <QueueCard 
                    key={entry.id}
                    entry={entry}
                    onSeat={() => seatCustomer(entry.id)}
                    onCancel={() => cancelEntry(entry.id)}
                    onRemove={() => removeEntry(entry.id)}
                    isCalled
                  />
                ))}
              </div>
            )}
            
            {/* Waiting customers */}
            {waitingQueue.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Waiting in Queue
                </h3>
                {waitingQueue.map((entry, index) => (
                  <QueueCard 
                    key={entry.id}
                    entry={entry}
                    position={index + 1}
                    onCall={() => callNext()}
                    onCancel={() => cancelEntry(entry.id)}
                    onRemove={() => removeEntry(entry.id)}
                    isFirst={index === 0}
                  />
                ))}
              </div>
            )}

            {waitingQueue.length === 0 && calledQueue.length === 0 && (
              <EmptyState 
                icon={Users}
                title="No customers waiting"
                description="Share your QR code to let customers join the queue"
              />
            )}
          </TabsContent>

          {/* Seated Tab */}
          <TabsContent value="seated" className="space-y-3">
            {seatedQueue.length > 0 ? (
              seatedQueue.map((entry) => (
                <QueueCard 
                  key={entry.id}
                  entry={entry}
                  onComplete={() => completeCustomer(entry.id)}
                  onRemove={() => removeEntry(entry.id)}
                  isSeated
                />
              ))
            ) : (
              <EmptyState 
                icon={UtensilsCrossed}
                title="No customers seated"
                description="Seated customers will appear here"
              />
            )}
          </TabsContent>

          {/* Appointments Tab */}
          <TabsContent value="appointments" className="space-y-3">
            {todaysAppointments.length > 0 ? (
              todaysAppointments.map((apt) => (
                <Card key={apt.id} className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <CalendarDays className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{apt.customerName}</p>
                          <p className="text-sm text-muted-foreground">
                            {apt.time} - Party of {apt.partySize}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{apt.time}</Badge>
                        <Badge variant="outline" className="text-success border-success">
                          Confirmed
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <EmptyState 
                icon={CalendarDays}
                title="No appointments today"
                description="Upcoming reservations will appear here"
              />
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* QR Code Modal */}
      {showQR && (
        <QRCodeDisplay 
          url={typeof window !== "undefined" 
            ? `${window.location.origin}/${qrType === "queue" ? "join" : "order"}/demo` 
            : `/${qrType === "queue" ? "join" : "order"}/demo`
          }
          restaurantName={restaurant.name}
          subtitle={qrType === "queue" ? "Scan to join the queue" : "Scan to order from your table"}
          onClose={() => setShowQR(false)}
        />
      )}
    </div>
  )
}

function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  color 
}: { 
  icon: React.ElementType
  label: string
  value: number
  color: string
}) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg bg-muted flex items-center justify-center ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold">{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function QueueCard({ 
  entry, 
  position,
  onCall,
  onSeat,
  onComplete,
  onCancel,
  onRemove,
  isFirst,
  isCalled,
  isSeated
}: { 
  entry: QueueEntry
  position?: number
  onCall?: () => void
  onSeat?: () => void
  onComplete?: () => void
  onCancel?: () => void
  onRemove?: () => void
  isFirst?: boolean
  isCalled?: boolean
  isSeated?: boolean
}) {
  const waitTime = Math.floor((Date.now() - new Date(entry.joinedAt).getTime()) / 60000)
  const orderTotal = entry.orders.reduce((sum, o) => sum + o.menuItem.price * o.quantity, 0)

  return (
    <Card className={`bg-card border-border ${isCalled ? "border-warning/50 bg-warning/5" : ""} ${isSeated ? "border-success/50 bg-success/5" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            {position && (
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-lg font-bold text-primary">#{position}</span>
              </div>
            )}
            {isCalled && (
              <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center shrink-0 animate-pulse">
                <Bell className="w-5 h-5 text-warning" />
              </div>
            )}
            {isSeated && (
              <div className="w-10 h-10 rounded-lg bg-success/20 flex items-center justify-center shrink-0">
                <UtensilsCrossed className="w-5 h-5 text-success" />
              </div>
            )}
            <div className="min-w-0">
              <p className="font-medium truncate">{entry.customerName}</p>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                <Badge variant="secondary" className="text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  {entry.partySize}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  {waitTime}m
                </Badge>
                {orderTotal > 0 && (
                  <Badge variant="outline" className="text-xs text-primary border-primary/50">
                    <UtensilsCrossed className="w-3 h-3 mr-1" />
                    ${orderTotal.toFixed(2)}
                  </Badge>
                )}
              </div>
              {entry.notes && (
                <p className="text-xs text-muted-foreground mt-2 truncate">
                  Note: {entry.notes}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {isFirst && onCall && (
              <Button size="sm" onClick={onCall} className="gap-1">
                <PhoneCall className="w-4 h-4" />
                Call
              </Button>
            )}
            {isCalled && onSeat && (
              <Button size="sm" onClick={onSeat} className="gap-1 bg-success hover:bg-success/90 text-success-foreground">
                <UserCheck className="w-4 h-4" />
                Seat
              </Button>
            )}
            {isSeated && onComplete && (
              <Button size="sm" variant="outline" onClick={onComplete} className="gap-1">
                <CheckCircle2 className="w-4 h-4" />
                Done
              </Button>
            )}
            {onCancel && !isSeated && (
              <Button size="sm" variant="ghost" onClick={onCancel}>
                <XCircle className="w-4 h-4 text-destructive" />
              </Button>
            )}
            {onRemove && (
              <Button size="sm" variant="ghost" onClick={onRemove}>
                <Trash2 className="w-4 h-4 text-muted-foreground" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function EmptyState({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ElementType
  title: string
  description: string
}) {
  return (
    <div className="text-center py-12">
      <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
        <Icon className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="font-medium text-lg mb-1">{title}</h3>
      <p className="text-muted-foreground text-sm">{description}</p>
    </div>
  )
}
