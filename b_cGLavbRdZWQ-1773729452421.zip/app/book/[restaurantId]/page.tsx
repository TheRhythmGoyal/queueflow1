"use client"

import { useState } from "react"
import Link from "next/link"
import { useAppointments, useRestaurant } from "@/hooks/use-queue"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { 
  Zap,
  ArrowLeft,
  CheckCircle2,
  CalendarDays,
  Clock,
  Users,
  User,
  Phone,
  Plus,
  Minus,
  Loader2,
  PartyPopper
} from "lucide-react"

type Step = "date" | "time" | "details" | "confirmed"

export default function BookAppointmentPage() {
  const { addAppointment, getAvailableSlots } = useAppointments()
  const restaurant = useRestaurant()
  
  const [step, setStep] = useState<Step>("date")
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    partySize: 2,
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [confirmedBooking, setConfirmedBooking] = useState<{
    date: string
    time: string
    name: string
    partySize: number
  } | null>(null)

  const availableSlots = selectedDate 
    ? getAvailableSlots(selectedDate.toISOString().split("T")[0])
    : []

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date)
    setSelectedTime(null)
    if (date) {
      setStep("time")
    }
  }

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time)
    setStep("details")
  }

  const handleSubmit = async () => {
    if (!selectedDate || !selectedTime || !formData.name || !formData.phone) return
    
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 800))
    
    addAppointment({
      customerName: formData.name,
      phone: formData.phone,
      date: selectedDate.toISOString().split("T")[0],
      time: selectedTime,
      partySize: formData.partySize,
      notes: formData.notes,
    })
    
    setConfirmedBooking({
      date: selectedDate.toISOString().split("T")[0],
      time: selectedTime,
      name: formData.name,
      partySize: formData.partySize,
    })
    setStep("confirmed")
    setIsSubmitting(false)
  }

  // Confirmed view
  if (step === "confirmed" && confirmedBooking) {
    return (
      <div className="min-h-screen bg-background">
        <BookingHeader restaurant={restaurant} />
        
        <main className="container mx-auto px-4 py-8 max-w-md">
          <Card className="bg-card border-border text-center">
            <CardContent className="pt-8 pb-8">
              <div className="w-20 h-20 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-success" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Booking Confirmed!</h2>
              <p className="text-muted-foreground mb-6">
                We look forward to seeing you
              </p>
              
              <div className="bg-muted rounded-xl p-6 text-left mb-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <CalendarDays className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Date</p>
                      <p className="font-medium">
                        {new Date(confirmedBooking.date).toLocaleDateString([], {
                          weekday: "long",
                          month: "long",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Time</p>
                      <p className="font-medium">{confirmedBooking.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Party Size</p>
                      <p className="font-medium">{confirmedBooking.partySize} guests</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Name</p>
                      <p className="font-medium">{confirmedBooking.name}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <Button asChild>
                  <Link href="/">Back to Home</Link>
                </Button>
                <Button variant="outline" onClick={() => {
                  setStep("date")
                  setSelectedDate(undefined)
                  setSelectedTime(null)
                  setFormData({ name: "", phone: "", partySize: 2, notes: "" })
                  setConfirmedBooking(null)
                }}>
                  Make Another Booking
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <BookingHeader restaurant={restaurant} />
      
      <main className="container mx-auto px-4 py-6 max-w-md">
        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <StepIndicator number={1} label="Date" active={step === "date"} completed={!!selectedDate} />
          <div className="w-8 h-px bg-border" />
          <StepIndicator number={2} label="Time" active={step === "time"} completed={!!selectedTime} />
          <div className="w-8 h-px bg-border" />
          <StepIndicator number={3} label="Details" active={step === "details"} completed={false} />
        </div>

        {/* Step: Select Date */}
        {step === "date" && (
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-primary" />
                Select a Date
              </CardTitle>
              <CardDescription>Choose when you would like to visit</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                disabled={(date) => date < new Date() || date > new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)}
                className="rounded-md border-0 mx-auto"
              />
            </CardContent>
          </Card>
        )}

        {/* Step: Select Time */}
        {step === "time" && selectedDate && (
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    Select a Time
                  </CardTitle>
                  <CardDescription>
                    {selectedDate.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}
                  </CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setStep("date")}>
                  Change Date
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {availableSlots.length > 0 ? (
                <div className="grid grid-cols-3 gap-2">
                  {availableSlots.map((slot) => (
                    <Button
                      key={slot}
                      variant={selectedTime === slot ? "default" : "outline"}
                      onClick={() => handleTimeSelect(slot)}
                      className="h-12"
                    >
                      {slot}
                    </Button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Clock className="w-12 h-12 mx-auto mb-4 opacity-30" />
                  <p>No available slots for this date</p>
                  <Button variant="link" onClick={() => setStep("date")}>
                    Select another date
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step: Enter Details */}
        {step === "details" && selectedDate && selectedTime && (
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Your Details
                  </CardTitle>
                  <CardDescription>
                    {selectedDate.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })} at {selectedTime}
                  </CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setStep("time")}>
                  Change Time
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  Your Name
                </label>
                <Input
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  Phone Number
                </label>
                <Input
                  type="tel"
                  placeholder="+1 555-0123"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  Party Size
                </label>
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFormData({ ...formData, partySize: Math.max(1, formData.partySize - 1) })}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="text-2xl font-bold w-12 text-center">{formData.partySize}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFormData({ ...formData, partySize: Math.min(12, formData.partySize + 1) })}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Special Requests (optional)</label>
                <Input
                  placeholder="Birthday celebration, dietary restrictions..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              {/* Booking Summary */}
              <div className="bg-muted rounded-lg p-4 mt-4">
                <h4 className="font-medium mb-3">Booking Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date</span>
                    <span>{selectedDate.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Time</span>
                    <span>{selectedTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Party Size</span>
                    <span>{formData.partySize} guests</span>
                  </div>
                </div>
              </div>

              <Button 
                className="w-full" 
                size="lg"
                onClick={handleSubmit}
                disabled={!formData.name || !formData.phone || isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Confirming...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Confirm Booking
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}

function BookingHeader({ restaurant }: { restaurant: { name: string; description: string } }) {
  return (
    <header className="border-b border-border bg-card/50">
      <div className="container mx-auto px-4 py-6">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{restaurant.name}</h1>
            <p className="text-sm text-muted-foreground">Book a Table</p>
          </div>
        </div>
      </div>
    </header>
  )
}

function StepIndicator({ 
  number, 
  label, 
  active, 
  completed 
}: { 
  number: number
  label: string
  active: boolean
  completed: boolean
}) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
        completed 
          ? "bg-success text-success-foreground" 
          : active 
            ? "bg-primary text-primary-foreground" 
            : "bg-muted text-muted-foreground"
      }`}>
        {completed ? <CheckCircle2 className="w-4 h-4" /> : number}
      </div>
      <span className={`text-xs ${active ? "text-foreground" : "text-muted-foreground"}`}>
        {label}
      </span>
    </div>
  )
}
