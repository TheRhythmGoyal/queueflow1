"use client"

import { useEffect, useState } from "react"
import { useQueue, useRestaurant } from "@/hooks/use-queue"
import { Badge } from "@/components/ui/badge"
import { 
  Users, 
  Clock, 
  Zap,
  Bell,
  QrCode,
  ArrowRight
} from "lucide-react"

export default function QueueDisplayPage() {
  const { queue } = useQueue()
  const restaurant = useRestaurant()
  const [currentTime, setCurrentTime] = useState(new Date())

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const waitingQueue = queue.filter((e) => e.status === "waiting")
  const calledQueue = queue.filter((e) => e.status === "called")

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-primary flex items-center justify-center">
              <Zap className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{restaurant.name}</h1>
              <p className="text-muted-foreground">Queue Display</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold font-mono">
              {currentTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </p>
            <p className="text-muted-foreground">
              {currentTime.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Now Serving - Takes up 1 column */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-border rounded-2xl p-6 h-full">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center">
                <Bell className="w-5 h-5 text-warning" />
              </div>
              <h2 className="text-xl font-semibold">Now Serving</h2>
            </div>
            
            {calledQueue.length > 0 ? (
              <div className="space-y-4">
                {calledQueue.map((entry) => (
                  <div 
                    key={entry.id}
                    className="bg-warning/10 border-2 border-warning rounded-xl p-6 animate-pulse"
                  >
                    <p className="text-4xl font-bold text-warning mb-2">
                      {entry.customerName}
                    </p>
                    <div className="flex items-center gap-4">
                      <Badge variant="outline" className="text-lg px-4 py-2 border-warning text-warning">
                        <Users className="w-4 h-4 mr-2" />
                        Party of {entry.partySize}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mt-4 text-lg">
                      Please proceed to the host stand
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground">
                <p className="text-lg">No customers being called</p>
              </div>
            )}
          </div>
        </div>

        {/* Queue List - Takes up 2 columns */}
        <div className="lg:col-span-2">
          <div className="bg-card border border-border rounded-2xl p-6 h-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <h2 className="text-xl font-semibold">Waiting Queue</h2>
              </div>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                {waitingQueue.length} waiting
              </Badge>
            </div>
            
            {waitingQueue.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {waitingQueue.slice(0, 8).map((entry, index) => (
                  <div 
                    key={entry.id}
                    className={`bg-muted/50 rounded-xl p-4 flex items-center gap-4 ${index === 0 ? "border-2 border-primary bg-primary/5" : "border border-border"}`}
                  >
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 ${index === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                      <span className="text-2xl font-bold">#{index + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-lg truncate">{entry.customerName}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {entry.partySize}
                        </span>
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {Math.floor((Date.now() - new Date(entry.joinedAt).getTime()) / 60000)}m
                        </span>
                      </div>
                    </div>
                    {index === 0 && (
                      <Badge className="bg-primary text-primary-foreground shrink-0">
                        Next
                        <ArrowRight className="w-4 h-4 ml-1" />
                      </Badge>
                    )}
                  </div>
                ))}
                {waitingQueue.length > 8 && (
                  <div className="col-span-full text-center py-4 text-muted-foreground">
                    +{waitingQueue.length - 8} more in queue
                  </div>
                )}
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-muted-foreground">
                <Users className="w-16 h-16 mb-4 opacity-30" />
                <p className="text-xl">Queue is empty</p>
                <p className="text-sm">Scan the QR code to join</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer with QR Code prompt */}
      <footer className="bg-card border-t border-border p-6">
        <div className="flex items-center justify-center gap-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <QrCode className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-lg">Scan to Join Queue</p>
              <p className="text-muted-foreground">Skip the line - join from your phone</p>
            </div>
          </div>
          <div className="hidden lg:block h-12 w-px bg-border" />
          <div className="hidden lg:flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
              <Clock className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <p className="font-semibold text-lg">~{waitingQueue.length * 15} min</p>
              <p className="text-muted-foreground">Estimated wait time</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
