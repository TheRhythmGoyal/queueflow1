"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { X, Download, QrCode } from "lucide-react"
import QRCode from "qrcode"

interface QRCodeDisplayProps {
  url: string
  restaurantName: string
  subtitle?: string
  onClose: () => void
}

export function QRCodeDisplay({ url, restaurantName, subtitle = "Scan to join the queue", onClose }: QRCodeDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, url, {
        width: 280,
        margin: 2,
        color: {
          dark: "#ffffff",
          light: "#1a1a2e",
        },
      })
    }
  }, [url])

  const downloadQR = () => {
    if (canvasRef.current) {
      const link = document.createElement("a")
      link.download = `${restaurantName.replace(/\s+/g, "-").toLowerCase()}-qr-code.png`
      link.href = canvasRef.current.toDataURL()
      link.click()
    }
  }

  return (
    <div 
      className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div 
        className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-primary" />
            <span className="font-semibold">Queue QR Code</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="text-center">
          <div className="bg-background rounded-xl p-4 inline-block mb-4">
            <canvas ref={canvasRef} className="rounded-lg" />
          </div>
          
          <h3 className="font-semibold text-lg mb-1">{restaurantName}</h3>
          <p className="text-sm text-muted-foreground mb-4">
            {subtitle}
          </p>

          <div className="bg-muted rounded-lg p-3 mb-4">
            <p className="text-xs text-muted-foreground break-all font-mono">{url}</p>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={downloadQR}>
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            <Button className="flex-1" onClick={onClose}>
              Done
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
