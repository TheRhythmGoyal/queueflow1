"use client"

import { useSyncExternalStore, useCallback } from "react"
import { queueStore } from "@/lib/queue-store"

export function useQueue() {
  const queue = useSyncExternalStore(
    queueStore.subscribe.bind(queueStore),
    () => queueStore.getQueue(),
    () => queueStore.getQueue()
  )

  return {
    queue,
    waitingCount: queue.filter((e) => e.status === "waiting").length,
    calledCount: queue.filter((e) => e.status === "called").length,
    seatedCount: queue.filter((e) => e.status === "seated").length,
    addToQueue: useCallback(queueStore.addToQueue.bind(queueStore), []),
    callNext: useCallback(queueStore.callNext.bind(queueStore), []),
    seatCustomer: useCallback(queueStore.seatCustomer.bind(queueStore), []),
    completeCustomer: useCallback(queueStore.completeCustomer.bind(queueStore), []),
    cancelEntry: useCallback(queueStore.cancelEntry.bind(queueStore), []),
    removeEntry: useCallback(queueStore.removeEntry.bind(queueStore), []),
    getPosition: useCallback(queueStore.getPosition.bind(queueStore), []),
    getEntry: useCallback(queueStore.getQueueEntry.bind(queueStore), []),
  }
}

export function useMenu() {
  return {
    menu: queueStore.getMenu(),
    getByCategory: queueStore.getMenuByCategory.bind(queueStore),
  }
}

export function useAppointments() {
  const appointments = useSyncExternalStore(
    queueStore.subscribe.bind(queueStore),
    () => queueStore.getAppointments(),
    () => queueStore.getAppointments()
  )

  return {
    appointments,
    addAppointment: useCallback(queueStore.addAppointment.bind(queueStore), []),
    cancelAppointment: useCallback(queueStore.cancelAppointment.bind(queueStore), []),
    getAvailableSlots: useCallback(queueStore.getAvailableSlots.bind(queueStore), []),
    getByDate: useCallback(queueStore.getAppointmentsByDate.bind(queueStore), []),
  }
}

export function useRestaurant() {
  return queueStore.getRestaurant()
}

export function useOrders(queueId: string) {
  const entry = useSyncExternalStore(
    queueStore.subscribe.bind(queueStore),
    () => queueStore.getQueueEntry(queueId),
    () => queueStore.getQueueEntry(queueId)
  )

  return {
    orders: entry?.orders || [],
    total: queueStore.getOrderTotal(queueId),
    addOrder: useCallback(
      (menuItem: Parameters<typeof queueStore.addOrder>[1], quantity?: number) =>
        queueStore.addOrder(queueId, menuItem, quantity),
      [queueId]
    ),
    removeOrder: useCallback(
      (menuItemId: string) => queueStore.removeOrder(queueId, menuItemId),
      [queueId]
    ),
  }
}
